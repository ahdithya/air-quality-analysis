# Air Quality Dashboard✨

## Setup environment

```
conda create --name main-ds python
conda activate main-ds
pip install -r requirements.txt
```

## Run steamlit app

```
cd dasboard
streamlit run app.py
```
